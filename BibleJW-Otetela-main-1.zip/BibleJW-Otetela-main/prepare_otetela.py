#!/usr/bin/env python3
import json, hashlib, html, re, shutil, tempfile, urllib.parse, urllib.request, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "app/src/main/assets"
SOURCE_ROOT = ASSETS / "OEBPS"

REFERENCE_SHA256 = "15db305ac8539e69daaf835b9b475a3bb43fb2e4a3c5a894bceff98f67ca5470"
REFERENCE_FILE = "nwt_OT.epub"
PUBLICATION_TITLE = "Bible—Ekadimwelo k’andja w’oyoyo"
EXPECTED_LANGUAGE = "tll"

def request(url):
    req = urllib.request.Request(url, headers={
        "Accept": "application/epub+zip, application/zip, application/octet-stream, */*",
        "Accept-Encoding": "identity",
        "User-Agent": "BibleJW-Otetela/4.8"
    })
    return urllib.request.urlopen(req, timeout=180)

def get_official_epub(locale, target):
    q = urllib.parse.urlencode({
        "alllangs": "0",
        "booknum": "0",
        "fileformat": "EPUB",
        "langwritten": locale,
        "output": "html",
        "pub": "nwt",
        "txtCMSLang": locale
    })
    api = "https://b.jw-cdn.org/apis/pub-media/GETPUBMEDIALINKS?" + q
    with request(api) as r:
        body = r.read()
    if body.startswith(b"PK"):
        target.write_bytes(body)
        return True
    try:
        data = json.loads(body.decode("utf-8-sig"))
    except Exception:
        return False
    urls = []
    def walk(x):
        if isinstance(x, dict):
            for v in x.values():
                if isinstance(v, str) and ".epub" in v.lower():
                    urls.append(v)
                else:
                    walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(data)
    if not urls:
        return False
    with request(urls[0]) as r, open(target, "wb") as out:
        shutil.copyfileobj(r, out)
    return True

def clean_text(s):
    s = re.sub(r"<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", html.unescape(s)).strip()

def links_in(text):
    return [(html.unescape(h), clean_text(t)) for h, t in re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>([\s\S]*?)</a>', text, re.I)]

def title_of(text):
    m = re.search(r"<title[^>]*>([\s\S]*?)</title>", text, re.I)
    return clean_text(m.group(1)) if m else ""

def chapter_entries(oebps, nav_href):
    text = (oebps / nav_href).read_text(encoding="utf-8")
    entries = []
    for href, label in links_in(text):
        if re.fullmatch(r"\d+", label) and href.lower().endswith((".xhtml", ".html")):
            entries.append({"n": label, "file": "OEBPS/" + href.lstrip("./")})
    # A chapter nav page also contains a back link and no other numbered links.
    return entries

def parse_epub(epub):
    oebps = ASSETS / "OEBPS"
    if oebps.exists():
        shutil.rmtree(oebps)
    oebps.mkdir(parents=True)

    with zipfile.ZipFile(epub) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = info.filename.replace("\\", "/")
            if not name.startswith("OEBPS/"):
                continue
            dest = ASSETS / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(z.read(info.filename))

    booknav = oebps / "biblebooknav.xhtml"
    if not booknav.is_file():
        raise RuntimeError("EPUB officiel incomplet : biblebooknav.xhtml absent.")
    book_links = [(h, t) for h, t in links_in(booknav.read_text(encoding="utf-8")) if h.lower().endswith((".xhtml", ".html"))]
    if len(book_links) != 66:
        raise RuntimeError(f"EPUB structure inattendue : {len(book_links)} livres au lieu de 66.")

    books = []
    for href, short_name in book_links:
        target = oebps / href.lstrip("./")
        if not target.is_file():
            raise RuntimeError(f"Lien de livre cassé dans l'EPUB : {href}")
        text = target.read_text(encoding="utf-8")
        if target.name.startswith("biblechapternav"):
            full_name = title_of(text) or short_name
            chapters = chapter_entries(oebps, href.lstrip("./"))
        else:
            full_name = title_of(text) or short_name
            # The five one-chapter books link directly to their XHTML content.
            chapters = [{"n": "1", "file": "OEBPS/" + href.lstrip("./")}]
        books.append({"name": full_name, "abbr": short_name, "chapters": chapters})

    chapter_count = sum(len(b["chapters"]) for b in books)
    verse_nav_count = len(list(oebps.glob("bibleversenav*.xhtml")))
    if chapter_count != 1189:
        raise RuntimeError(f"EPUB structure inattendue : {chapter_count} chapitres au lieu de 1189.")
    if verse_nav_count != 1189:
        raise RuntimeError(f"EPUB navigation inattendue : {verse_nav_count} navigations de versets au lieu de 1189.")

    genesis = (oebps / "1001061105.xhtml").read_text(encoding="utf-8")
    for marker in (
        "Lo etatelo, Nzambi akatonge olongo la nkɛtɛ.",
        "L’etena kɛsɔ",
        "Ko Nzambi akate ate"
    ):
        if marker not in genesis:
            raise RuntimeError("L’EPUB ne correspond pas à la Bible Otétéla officielle attendue.")

    index = {
        "language": "Ɔtɛtɛla",
        "source": "JW.ORG — EPUB officiel",
        "referenceFile": REFERENCE_FILE,
        "referenceSha256": REFERENCE_SHA256,
        "publicationTitle": PUBLICATION_TITLE,
        "books": books,
        "chapterNavigationCount": chapter_count,
        "verseNavigationCount": verse_nav_count,
        "navigation": {
            "book": "OEBPS/biblebooknav.xhtml",
            "chapterPattern": "OEBPS/biblechapternav*.xhtml",
            "versePattern": "OEBPS/bibleversenav*.xhtml"
        }
    }
    (ASSETS / "bible_index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    cover = oebps / "images/1001061100_OT_cvr.jpg"
    if cover.is_file():
        shutil.copy2(cover, ASSETS / "cover_small.jpg")

    # Ajustements visuels uniquement : aucune modification du texte ni de l'ordre EPUB.
    # La page Livres reste fidèle à la navigation EPUB officielle, sans logo ajouté dans la page.
    booknav_text = booknav.read_text(encoding="utf-8")
    booknav_style = """\n<style id="biblejw-book-layout" type="text/css">
/* BibleJW Otétéla : mise en page, sans modifier le contenu EPUB. */
body.jwac.pub-nwt.w_bible_books_screen { margin: 6mm 3mm; }
table.w_navigation.w_bibleBook { width: 100%; max-width: 920px; margin-left: auto; margin-right: auto; }
table.w_navigation.w_bibleBook td.w_navigation.w_bibleBook { text-align: center; padding-top: 12px; padding-bottom: 12px; }
table.w_navigation.w_bibleBook td.w_navigation.w_bibleBook a { font-size: 1.25em; line-height: 1.5; }
</style>
"""
    if "biblejw-book-layout" not in booknav_text:
        booknav_text = booknav_text.replace("</head>", booknav_style + "</head>", 1)
    booknav.write_text(booknav_text, encoding="utf-8")

    # Marges demandées pour TOUTES les pages : haut/bas 6 mm, droite/gauche 3 mm.
    # Ceci ne touche que la mise en page (CSS injecté dans <head>) ; le contenu XHTML
    # (texte, renvois marginaux, notes, liens) reste exactement celui de la source EPUB.
    margin_style = """<style id="biblejw-reading-margins" type="text/css">
/* Marges d'affichage, toutes les pages de la source EPUB : haut/bas 6 mm, droite/gauche 3 mm. */
html, body { margin: 6mm 3mm !important; }
</style>
"""
    def add_margin_style(path):
        text = path.read_text(encoding="utf-8")
        if "biblejw-reading-margins" not in text:
            text = text.replace("</head>", margin_style + "</head>", 1)
            path.write_text(text, encoding="utf-8")

    # Toutes les pages livrées dans OEBPS (navigation des livres, navigation des
    # chapitres, navigation des versets, pages de lecture, et toute autre page
    # présente dans l'EPUB officiel telle que couverture, titre ou copyright).
    all_pages = sorted(set(oebps.rglob("*.xhtml")) | set(oebps.rglob("*.html")))
    if not all_pages:
        raise RuntimeError("Aucune page XHTML/HTML trouvée dans l'EPUB officiel.")
    for path in all_pages:
        add_margin_style(path)

    # Identité visuelle de l'APK : couverture officielle comme icône Android.
    res_drawable = ROOT / "app/src/main/res/drawable"
    res_drawable.mkdir(parents=True, exist_ok=True)
    if cover.is_file():
        shutil.copy2(cover, res_drawable / "ic_launcher_cover.jpg")

    (ASSETS / "SOURCE_LANGUAGE.txt").write_text(
        "Source exclusive : JW.ORG — Bible Otétéla, EPUB officiel nwt.\n"
        "Navigation : EPUB original (livres → chapitres → versets).\n"
        "Le texte, la langue, les liens et les renvois restent issus de la source officielle.\n"
        "La couverture officielle est utilisée uniquement comme identité visuelle de l’APK, pas comme logo dans la page Livres.\n"
        "Mise en page d’affichage : marges haut/bas 6 mm et droite/gauche 3 mm pour navigation et lecture.\n",
        encoding="utf-8"
    )

    # No custom parameter menu: the application opens the original EPUB navigation directly.
    (ASSETS / "bible_library.html").write_text(
        '<!doctype html><html lang="tll"><head><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=OEBPS/biblebooknav.xhtml"></head>'
        '<body><script>location.replace("OEBPS/biblebooknav.xhtml");</script></body></html>',
        encoding="utf-8"
    )
    return index

def main():
    with tempfile.TemporaryDirectory() as td:
        pkg = Path(td) / "nwt_OT.epub"
        ok = False
        errors = []
        for locale in ("tll", "ot", "OTE", "TLL"):
            try:
                if get_official_epub(locale, pkg):
                    actual = hashlib.sha256(pkg.read_bytes()).hexdigest()
                    if actual == REFERENCE_SHA256:
                        print("EPUB Otétéla officiel JW.ORG obtenu, locale", locale)
                        ok = True
                        break
                    errors.append(f"{locale}: hash {actual}")
            except Exception as e:
                errors.append(f"{locale}: {e}")
        if not ok:
            raise RuntimeError(
                "L’EPUB officiel JW.ORG ne correspond pas exactement à la référence nwt_OT.epub. "
                + " | ".join(errors)
            )
        index = parse_epub(pkg)
        print(f"PASS EPUB: {len(index['books'])} livres / {index['chapterNavigationCount']} chapitres / {index['verseNavigationCount']} navigations de versets")

if __name__ == "__main__":
    main()
