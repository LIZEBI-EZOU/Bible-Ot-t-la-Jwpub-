# Bible JW — Otétéla

Application Android hors ligne pour la Bible JW en Otétéla.

- 66 livres bibliques
- 1 189 chapitres
- Les chapitres sont copiés depuis l’EPUB officiel sans réécriture du contenu XHTML.
- Interface Otétéla avec navigation, recherche de livres/chapitres, mode sombre et signets.
- Validation automatique avant compilation.

Le workflow GitHub Actions prépare la source, valide les 66 livres/1 189 chapitres, puis construit un APK Android installable.