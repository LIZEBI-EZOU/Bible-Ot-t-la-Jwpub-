import hashlib, json, os, re, zipfile

root = os.path.dirname(os.path.abspath(__file__))
assets = os.path.join(root, "app/src/main/assets")
data = json.load(open(os.path.join(assets, "bible_index.json"), encoding="utf-8"))
books = data["books"]
chapters = sum(len(b["chapters"]) for b in books)

assert len(books) == 66, f"Expected 66 books, got {len(books)}"
assert chapters == 1189, f"Expected 1189 chapters, got {chapters}"
assert data.get("verseNavigationCount") == 1189, f"Expected 1189 verse navigation files, got {data.get('verseNavigationCount')}"
assert str(data.get("language","")).lower() in ("Ɔtɛtɛla".lower(), "otétéla"), "Bible language is not Otétéla"
assert str(data.get("source","")).startswith("JW.ORG — EPUB"), "Bible source is not official JW.ORG EPUB"
assert data.get("referenceFile") == "nwt_OT.epub", "Wrong EPUB reference"
assert data.get("referenceSha256") == "15db305ac8539e69daaf835b9b475a3bb43fb2e4a3c5a894bceff98f67ca5470", "Wrong EPUB reference hash"
assert data.get("publicationTitle") == "Bible—Ekadimwelo k’andja w’oyoyo", "Wrong publication title"
assert os.path.isfile(os.path.join(assets, "OEBPS", "biblebooknav.xhtml")), "Missing original EPUB book navigation"
assert os.path.isfile(os.path.join(assets, "OEBPS", "css", "epubs.css")), "Missing original EPUB CSS"
assert os.path.isfile(os.path.join(assets, "cover_small.jpg")), "Missing Bible cover"
assert os.path.isfile(os.path.join(assets, "OEBPS", "images", "1001061100_OT_cvr.jpg")), "Missing official Bible cover in EPUB"

genesis = os.path.join(assets, "OEBPS", "1001061105.xhtml")
txt = open(genesis, encoding="utf-8").read()
for marker in (
    "Lo etatelo, Nzambi akatonge olongo la nkɛtɛ.",
    "L’etena kɛsɔ",
    "Ko Nzambi akate ate"
):
    assert marker in txt, f"Official Otétéla marker missing from Genesis 1: {marker}"

# Vérifier que la navigation EPUB réelle est complète.
booknav = open(os.path.join(assets, "OEBPS", "biblebooknav.xhtml"), encoding="utf-8").read()
book_links = re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>', booknav, re.I)
book_links = [h for h in book_links if h.lower().endswith((".xhtml", ".html"))]
assert len(book_links) == 66, f"EPUB book navigation has {len(book_links)} books"
assert 'class="bible-app-logo"' not in booknav, "Bible logo must not appear in the book navigation"
assert "6mm 3mm" in booknav, "Book navigation margins are not 6mm top/bottom and 3mm left/right"
assert "font-size: 1.25em" in booknav, "Book navigation font size was not increased"
assert "margin-left: auto" in booknav and "margin-right: auto" in booknav, "Book list is not centered"
assert r"\\1" not in booknav and r"\\2" not in booknav, "Invalid regex backreferences leaked into EPUB XHTML"
assert 'biblejw-book-layout' in booknav, "Book navigation layout style is missing"

# Marges 6 mm / 3 mm sur TOUTES les pages de l'EPUB (navigation des livres, des
# chapitres, des versets, pages de lecture, et toute autre page de la source).
margin_marker = 'biblejw-reading-margins'
oebps_dir = os.path.join(assets, "OEBPS")
all_pages = []
for dirpath, _dirnames, filenames in os.walk(oebps_dir):
    for fn in filenames:
        if fn.lower().endswith((".xhtml", ".html")):
            all_pages.append(os.path.join(dirpath, fn))
assert all_pages, "No XHTML/HTML pages found under OEBPS"
for page in all_pages:
    page_text = open(page, encoding="utf-8").read()
    assert margin_marker in page_text, f"Missing requested margins (6mm/3mm) in {os.path.relpath(page, oebps_dir)}"
for b in books:
    for c in b["chapters"]:
        rel = c["file"].removeprefix("OEBPS/")
        page = os.path.join(assets, "OEBPS", rel)
        page_text = open(page, encoding="utf-8").read()
        assert margin_marker in page_text, f"Missing requested reading margins in {rel}"

manifest = open(os.path.join(root, "app/src/main/AndroidManifest.xml"), encoding="utf-8").read()
assert '@drawable/ic_launcher_cover' in manifest, "Official Bible cover is not the APK identity icon"
assert os.path.isfile(os.path.join(root, "app/src/main/res/drawable/ic_launcher_cover.jpg")), "APK cover icon was not generated"

for b in books:
    assert b.get("name"), "Book without official EPUB title"
    assert b.get("chapters"), f"Book without chapters: {b.get('name')}"
    for c in b["chapters"]:
        rel = c["file"].removeprefix("OEBPS/")
        p = os.path.join(assets, "OEBPS", rel)
        assert os.path.isfile(p), f"Missing EPUB chapter target: {c['file']}"

verse_files = [x for x in os.listdir(os.path.join(assets, "OEBPS")) if x.startswith("bibleversenav") and x.endswith(".xhtml")]
assert len(verse_files) == 1189, f"Missing EPUB verse navigation files: {len(verse_files)}"

# Chaque navigation de chapitre et de verset doit pointer vers un fichier présent.
for name in os.listdir(os.path.join(assets, "OEBPS")):
    if name.startswith(("biblechapternav", "bibleversenav")) and name.endswith(".xhtml"):
        p = os.path.join(assets, "OEBPS", name)
        s = open(p, encoding="utf-8").read()
        for href in re.findall(r'<a[^>]+href=["\']([^"\']+)["\']', s, re.I):
            if href.startswith(("http://", "https://", "#")):
                continue
            rel = href.split("#",1)[0]
            target = os.path.normpath(os.path.join(os.path.dirname(p), rel))
            assert os.path.isfile(target), f"Broken EPUB navigation link in {name}: {href}"

library = open(os.path.join(assets, "bible_library.html"), encoding="utf-8").read()
assert "OEBPS/biblebooknav.xhtml" in library, "Launcher does not use EPUB navigation"

print(f"PASS EPUB: {len(books)} books / {chapters} chapters / {data['verseNavigationCount']} verse navigation files")
print("PASS: original EPUB XHTML, CSS, fonts, links, cover and Otétéla text verified")
